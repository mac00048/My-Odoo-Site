{
    'name': 'Custom Offer Email',
    'version': '1.0',
    'author': 'Your Name',
    'depends': ['base'],
    'data': [],
}
